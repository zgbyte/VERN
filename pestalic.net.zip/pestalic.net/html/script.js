document.addEventListener('DOMContentLoaded', function() {
    const tables = document.querySelectorAll('.table-container');

    tables.forEach(function(table) {
        table.addEventListener('click', function() {
            showPopup(table.id);
        });
    });
});

function showPopup(tableId) {
    const tableNumber = tableId.replace(/[^\d]/g, '');
    const popup = document.getElementById('popup');
    
    if (popup) {
        // Set the innerHTML of the popup with a form
        popup.innerHTML = `
                <div class="popup-content">
                <span class="close" onclick="closePopup()">&times;</span>
                <h2>Rezervacija za stol broj: ${tableNumber}</h2>
                <form id="reservation-form">
                    <div class="form-group">
                    <label for="name">Ime:</label>
                    <input type="text" id="name" name="name" placeholder="Pero" required>
                    </div>
                    <div class="form-group">
                        <label for="surname">Prezime:</label>
                        <input type="text" id="surname" name="surname" placeholder="Perić" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Broj telefona:</label>
                        <input type="tel" id="phone" name="phone" placeholder="0912345678" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Mail:</label>
                        <input type="email" id="email" name="email" placeholder="mail@mail.com" required>
                    </div>
                    <button type="submit" class="btn">Rezerviraj</button>
                    <p class="additional-text">Nakon što kliknete "Rezerviraj" dobit ćete potvrdu na mail.</p>
                </form>
            </div>`;
        // Show the popup
        popup.style.display = 'flex';
        
        // Now that the form exists, we can attach the event handler
        attachFormSubmitHandler();
    }
}

function attachFormSubmitHandler() {
    const form = document.getElementById('reservation-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);

            fetch('mail.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                alert(data); // Alert the message from mail.php
                closePopup(); // Close the popup after sending the email
            })
            .catch(error => {
                alert('Error:' + error);
            });
        });
    }
}

function closePopup() {
    const popup = document.getElementById('popup');
    if (popup) {
        popup.style.display = 'none';
    }
}
