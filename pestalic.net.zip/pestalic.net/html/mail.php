<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Load Composer's autoloader

$mail = new PHPMailer(true); // Passing `true` enables exceptions

try {
    //Server settings
    $mail->SMTPDebug = 2; // Enable verbose debug output
    $mail->isSMTP(); // Set mailer to use SMTP
    $mail->Host = 'smtp-mail.outlook.com'; // Specify main and backup SMTP servers
    $mail->SMTPAuth = true; // Enable SMTP authentication
    $mail->Username = 'test@hasbikg.onmicrosoft.com'; // SMTP username
    $mail->Password = '0n3T1m3Kcd!!'; // SMTP password
    $mail->SMTPSecure = 'ssl'; // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587; 

    //Recipients
    $mail->setFrom('damir.pestalic@gmail.com', 'VERN" Noćni klub');
    $mail->addAddress($_POST['email']); 

    //Content
    $mail->isHTML(true); 
    $mail->Subject = 'VERN" Noćni klub rezervacija';
    $mail->Body    = "Poštovani, uspješno ste rezervirali stol " . $_POST['tableNumber'] . " na prezime " . $_POST['surname'] . ".";
    $mail->AltBody = "Poštovani, uspješno ste rezervirali stol " . $_POST['tableNumber'] . " na prezime " . $_POST['surname'] . ".";

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
?>
